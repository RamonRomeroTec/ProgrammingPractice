Console Spreadsheet.
Copyright 2019 © Ramon Romero   @RamonRomeroQro

Read .tsv Spreadsheet and print its evaluation.
 
$ python3 program.py [.tsv file to evaluate]
